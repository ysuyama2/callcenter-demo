var Model = {};

//コールログテーブルのスキーマ
Model.call_log = {
	 id :""
	,dial_call_sid :""
	,phone_number :""
	,dial_call_duration :""
	,recording_url :""
	,created_date :""
	,sound_data :""
};

module.exports = Model;